## Installation for ARAC 255

 1.Run the "ARAC_80-255-FULL.sql" script on your database. This script will make the necessary modifications to enable character creation with all classes and races. Please exercise caution when making changes to your database and ensure you have a backup.
