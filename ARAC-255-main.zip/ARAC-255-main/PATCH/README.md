## PATCH

players should place the "Patch-A.MPQ" file inside their World of Warcraft client's data folder. This file ensures that the necessary game files are updated to support ARAC.
